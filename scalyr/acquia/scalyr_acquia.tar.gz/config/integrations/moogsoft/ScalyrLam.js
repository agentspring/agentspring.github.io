/************************************************************
 *              Copyright (c) Moogsoft Inc 2018             *
 *                                                          *
 *----------------------------------------------------------*
 *                                                          *
 * The contents of this configuration file may be copied,   *
 * amended and used to create derivative works.             *
 *                                                          *
 ************************************************************/
//-----------------------------------------------------------------
// Modules:
//
// There are currently two modules
// Logger:
//
// Provide stdout logging functionality. Has 3 methods:
//
//  info("string " + var)
//   Log an info message, takes vararg arguments, after first string
//  warning("string")
//   Log a warning message, takes vararg arguments, after first string
//  fatal(varA + " string " + varB " string")
//   Log an fatal message, takes vararg arguments, after first string
//   Execution will cease and core is dumped after this
//
// Constants:
//
// Provides a shared, synchronised scratch pad shared by all LamBots
//
// Supports:
//
//  put(key,val), where key and val can be any legal JS variable
//  returns null, or existing value stored at key
//  contains(key), returns true if there is a value stored at key
//  remove(key), removes any variable stored at key, returns 
//  stored variable if not empty, or null if no value stored.
//  get(key), retrieve the value stored at key, null if none stored.
//-----------------------------------------------------------------
//
// Load necessary modules
//
var logger=LamBot.loadModule("Logger");
var constants=LamBot.loadModule("Constants");

// Signature cannot be longer than that (db column length).
var MAX_SIG_LENGTH = 767;

//---------------------------------------------
// This function is called when the LamBot is
// first initailised in the LAM, allowing the 
// construction/ of any structures necessary 
// for the running of the filter function
//---------------------------------------------
function onLoad()
{
    /* COMMENT BLOCK BEGIN

    // Some example scratch pad manipulations
    var testObject={ strField: "Hello Moog" };
    if(constants.contains("key1") == false)
    {
        constants.put("key1",2);
    }
    logger.info("Key: key2, store status: " + constants.contains("key2"));

    // Store a whole object
    var obj=constants.put("key2",testObject);
    if(obj)
    {
        logger.info("Old object is " + obj.strField);
    }

    // Some gets
    var foundValue=constants.get("key1");
    if(foundValue)
    {
        logger.info("key1 value is " + foundValue);
    }
    foundValue=constants.get("key2");
    if(foundValue)
    {
        logger.info("key2 value is " + foundValue.strField);
    }

    // And a remove
    var oldObj=constants.remove("key2");
    if(oldObj!==null)
    {
        logger.info("Old object is " + oldObj.strField);
    }

    logger.info("onLoad() called");

    END COMMENT BLOCK */

    return;
}

//
// Before sending add overflow data and make sure signature is set.
//
function presend(event)
{

    //
    // returning true, makes this an event on the MooMs bus. 
    // false will cause the LAM to discard the event.
    // To define streams return an Object like:
    // return ({
    //     "stream" : "my_stream",
    //     "passed" : true
    // });
    //
  
    /* Using Constants Example
    if(constants.contains("myKey"))
    {
        event.set("manager",constants.get("myKey"));
    }
    else
    {
        constants.put("myKey","myValue");
    }
    */
    
    /* Logging Example
    logger.warning("hello... is it me you're lamming for ?");
    */

    var lamName = ((event.value("agent") !== "$agent") || (event.value("agent") !== "")) ? 
        event.value("agent") : "Scalyr";
    var overflow = {};
    var custom_info = {};

    // Parse overflow values received:
    try
    {
        overflow = JSON.parse(event.value("overflow"));
    }
    catch(e)
    {
        logger.warning(lamName + ": " + "Failed to parse overflow data for this event: " + e);
    }

    // Check LamInstanceName value and if it's default value, remove it from 
    // the custom_info object
    if ( overflow.LamInstanceName && (overflow.LamInstanceName === "DATA_SOURCE") )
    {
        delete overflow.LamInstanceName;
    }

    // Add the overflow object as eventDetails and stringify it before adding 
    // to the Moogsoft AIOps event.
    custom_info.eventDetails = overflow;
    event.set("custom_info", JSON.stringify(custom_info));

    // Check whether a signature has been set for the event received. 
    // If not, create one based on the concatenation of the values set for: 
    // source, source_id, external_id, manager, agent, class.
    if ((event.value("signature") === "$signature") || (event.value("signature") === ""))
    {
        var eSignature = "";
        var fields = [ "source_id", "manager", "agent", "class" ];

        // Check if the values have been received, and if so, add to the 
        // event's signature. 
        if ((event.value("source") !== "$source") && (event.value("source") !== ""))
        {
            eSignature += event.value("source");
        }

        for (var i = 0; i < fields.length; i++)
        {
            var value = event.value(fields[i]);
            var placeholder = "$" + fields[i];

            eSignature += ":";
            if ((value !== placeholder) && (value !== ""))
            {
                eSignature += value;
            }
        }

        // Concatenated signature might be too long so use hash instead.
        if (eSignature !== "")
        {
            var finalSignature = (eSignature.length <= MAX_SIG_LENGTH)? 
                eSignature : 
                getHashCode(eSignature).toString();
            event.set("signature", finalSignature);
        }
        else
        {
            logger.warning(lamName + ": " + "Failed to automatically create event signature.");
        }
    }

    // Set the agent_time and first_occurred to the current time
    var recTime = Math.round(Date.now() / 1000);
    event.set("agent_time", recTime);
    event.set("first_occurred", recTime);

    return true;
}

//
// Helper method to get a hash of a string. Useful when dealing with 
// potentially lenghty signatures.
// This implementation is the same as in Java's String.hashCode().
//
function getHashCode(text)
{
    var hash = 0;

    if (text.length == 0)
    {
        return hash;
    }

    for (i = 0; i < text.length; i++)
    {
        var char = text.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        
        // Convert to 32bit integer.
        hash = hash & hash;
    }

    return hash;
}

//
// Tell the LamBot that we filter using the presend function
//
LamBot.filterFunction("presend");
