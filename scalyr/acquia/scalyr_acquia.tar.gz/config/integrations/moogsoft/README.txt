Steps Needed to Implement the Integration:

1. Scalyr Agent
   Edit and copy scalyr-moogsoft-fields.json to agent.d directory.
   Once applied, this will result in all new Acquia logs entries being tagged 
   with attributes specific to your site. (See file comments for details)

2. Moogsoft
   Start new REST monitor using the provided configuration files:
   - scalyr.config  (defaults to listening port 8888)
     Save this into the $MOOGSOFT_HOME/config directory on the server 
     where LAMs are running. Make sure the file is owned by the Moogsoft user.

   - Scalyrlam.js
   Save this into the $MOOGSOFT_HOME/bots/lambots directory on the server 
   where LAMs are running. Make sure the file is owned by the Moogsoft user 
   and chmod to 755.

3. Test Moogsoft (Optional but recommended)
   Use Fiddler, Postman, curl or similar utility to test Moogsoft by 
   sending it a representative JSON payload (file: test-payload.json)

4. Scalyr Alerts - webhooks

   Scalyr needs to be configured to send events to Moogsoft.  
   This is done using webhooks as the notification method.

   A new Alerts json is supplied with the integration 
   File: scalyr-moogsoft-alerts.json

   Update the file changing the target URL from 'http://example.com:8888' to the
   values configured for Moogsoft then update Scalyr using the Scalyr command-line tool:

   $ scalyr put-file /scalyr/alerts < scalyr-moogsoft-alerts.json

   or, via the Scalyr web console, open the Edit Alerts page then copy/paste
   over the existing alert json. (Save existing before overwriting)

