#!/bin/sh
# Date: 2018-01-22
# projects@agentspring.com
#
# Installs Parsers, Searches, Alerts, Dashboards and Monitors
# Backup user configs that could possibly be overwritten
#

ts=$(date +%Y%m%d%H%M%S)

echo "--- Currently Installed Parsers -----------------------------------------"
./scalyr list-files | egrep "/logParsers"
status=$?
if [ $status -ne 0 ]; then
   echo "$0: command-line tool encountered a problem."
   echo "exited with status: $status." 
   exit $status
fi
echo "---"
echo "Installing Parsers..."
./scalyr put-file /logParsers/as_acq_ApacheAccessLog   < ./config/logParsers/as_acq_ApacheAccessLog

./scalyr put-file /logParsers/as_acq_ApacheErrorLog    < ./config/logParsers/as_acq_ApacheErrorLog
./scalyr put-file /logParsers/as_acq_DrupalRequestsLog < ./config/logParsers/as_acq_DrupalRequestsLog
./scalyr put-file /logParsers/as_acq_DrupalWatchdogLog < ./config/logParsers/as_acq_DrupalWatchdogLog
./scalyr put-file /logParsers/as_acq_FpmAccessLog < ./config/logParsers/as_acq_FpmAccessLog
./scalyr put-file /logParsers/as_acq_FpmErrorLog  < ./config/logParsers/as_acq_FpmErrorLog
./scalyr put-file /logParsers/as_acq_PhpErrorLog  < ./config/logParsers/as_acq_PhpErrorLog
./scalyr put-file /logParsers/as_acq_RsyncLog     < ./config/logParsers/as_acq_RsyncLog
./scalyr put-file /logParsers/as_acq_DrushCronLog < ./config/logParsers/as_acq_DrushCronLog
echo "Done. Parsers Installed..."
echo "--- Parsers after Install -----------------------------------------------"
./scalyr list-files | egrep "/logParsers"
echo ""
sleep 1

echo Backuping up Searches...
./scalyr get-file /scalyr/searches > ./backups/searches.$ts
echo Installing Searches...
./scalyr put-file /scalyr/searches < ./config/searches/searches
echo "Done. Searches Installed."
echo ""
sleep 1

echo Backuping up Alerts...
./scalyr get-file /scalyr/alerts > ./backups/alerts.$ts
echo Installing Alerts...
./scalyr put-file /scalyr/alerts < ./config/alerts/alerts
echo "Done. Alerts Installed."
echo ""
sleep 1

echo Backuping up Monitors...
./scalyr get-file /scalyr/monitors > ./backups/monitors.$ts
echo Installing Monitors...
./scalyr put-file /scalyr/monitors < ./config/monitors/monitors
echo "Done. Monitors Installed."
echo ""
sleep 1

echo Installing Dashboards...
./scalyr put-file /dashboards/Acquia-Diagnostics < ./config/dashboards/Acquia-Diagnostics
./scalyr put-file /dashboards/Acquia-Performance < ./config/dashboards/Acquia-Performance
./scalyr put-file /dashboards/Acquia-Top-Stats   < ./config/dashboards/Acquia-Top-Stats
echo "Done. Dashboards Installed."

echo "--- Searches, Alerts, Dashboards and Monitors after Install -------------"
./scalyr list-files | egrep "/alerts|/dash|/monitors|/searches"

echo ""
echo "Backups of searches, alerts and monitors configurations saved to ./backups with timestamp of '$ts'"
