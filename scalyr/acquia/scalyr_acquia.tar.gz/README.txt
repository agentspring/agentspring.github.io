Acquia Log Aggregation and Analytics Using Scalyr

Files contained in this archive support monitoring logs of Drupal sites
hosted in the Acquia Cloud using Scalyr.

Documentation:
https://agentspring.github.io/scalyr-acquia/

Contact: projects@agentspring.com
