#!/bin/bash
# Date:2017-12-11
# dgerhard - projects@agentspring.com
# AgentSpring, LLC
#
# Executes rsync command to copy active logs ('*.log' by default)
# from the identified Acquia server.
#
# Adjust the follow variables for your environment
#
# Example:
#ACQUIA_SSH_ADDR=example.prod@srv-1234.devcloud.hosting.acquia.com
#ACQUIA_LOG_PATH=/var/log/sites/example.prod/logs/srv-1234

ACQUIA_SSH_ADDR=_YOUR_SSH_ADDRESS_
ACQUIA_LOG_PATH=_YOUR_LOG_PATH_ #dont add trailing /

ACQUIA_FILES='*.log'	        #change to '*' if want log archives also

ACQUIA_SITE_ENVS="prod test dev" #which environments to monitor: prod test dev

LOCAL_LOG_PATH=/var/log/acquia	#base directory where logs are copied to
SSH_TIMEOUT=10			#seconds. Keep < scheduled frequency
IO_TIMEOUT=0			#seconds. rsync I/O timeout. 0=none

# rsync Comamnd options:
# For verbose output change the q switch to v
# Remove z to prevent compression

base_log_path="${ACQUIA_LOG_PATH%\.*}"
end_log_path="/logs${ACQUIA_LOG_PATH#/*/logs}"

# Loop through each environment
for site_env in $ACQUIA_SITE_ENVS
do
   acquia_log_path="${base_log_path}.${site_env}${end_log_path}"
   rsync -zv --timeout=$IO_TIMEOUT -e "ssh -o ConnectTimeout=$SSH_TIMEOUT" --inplace $ACQUIA_SSH_ADDR:$acquia_log_path/$ACQUIA_FILES $LOCAL_LOG_PATH/$site_env/ 
   status=$?
   if [ $status -ne 0 ]; then
      echo "$(date) rsync error: exit status $status. Trying $ACQUIA_SSH_ADDR:$acquia_log_path"
      exit $status #If failed for one will likely fail for all, so exit
   fi
done
exit
